from ._augmentedenum import AugmentedEnum


class DimensionNames(AugmentedEnum):
    X = "x"
    Y = "y"
