# this import is here for compatibility reasons
from slicedimage.url.path import join as pathjoin  # noqa
